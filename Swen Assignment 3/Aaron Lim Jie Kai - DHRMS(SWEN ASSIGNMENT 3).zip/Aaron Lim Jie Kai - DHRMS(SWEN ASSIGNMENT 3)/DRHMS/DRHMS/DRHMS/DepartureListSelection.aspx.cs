﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DRHMS
{
    public partial class WebForm15 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=USER-PC\\SQLEXPRESS;Initial Catalog=DelonixRegia;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string str = "SELECT Room.RoomType, Room.RoomLevel, Room.RoomRates, Guests.MGPassportNo, Guests.MGFirstName, Guests.MGTitle, Guests.MGLastName, Guests.MGNationality, Guests.NoOfGuest,Guests.MGPhoneNumber, Guests.MGFullAddress, Booking.RoomNumber, Booking.CheckOutDate, Booking.CheckOutTime FROM Booking INNER JOIN Room ON Booking.RoomID = Room.RoomID INNER JOIN Guests ON Booking.MGPassportNo = Guests.MGPassportNo WHERE Booking.CheckOutDate=@CheckOutDate";
            SqlCommand xp = new SqlCommand(str, con);
            xp.Parameters.Add("@CheckOutDate", SqlDbType.VarChar).Value = TextBox1.Text;
            con.Open();
            xp.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = xp;
            DataSet ds = new DataSet();
            da.Fill(ds, "CheckOutDate");
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();


            if (TextBox1.Text == String.Empty)
            {
                Label2.Text = "Please enter Check out date";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Report centre.aspx");

        }
    }
}