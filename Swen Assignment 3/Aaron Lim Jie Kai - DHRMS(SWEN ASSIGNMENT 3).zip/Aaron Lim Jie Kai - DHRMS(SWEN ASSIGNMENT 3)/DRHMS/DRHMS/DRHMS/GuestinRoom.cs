﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS
{
    public class GuestinRoom
    {
        private string checkindate;

        public string Checkindate
        {
            get { return checkindate; }
            set { checkindate = value; }
        }

        private string checkoutndate;

        public string Checkoutndate
        {
            get { return checkoutndate; }
            set { checkoutndate = value; }
        }

        private string mgtitle;

        public string Mgtitle
        {
            get { return mgtitle; }
            set { mgtitle = value; }
        }

        private string mgfirstname;

        public string Mgfirstname
        {
            get { return mgfirstname; }
            set { mgfirstname = value; }
        }

        private string mglastname;

        public string Mglastname
        {
            get { return mglastname; }
            set { mglastname = value; }
        }

        private string secgfirstname;

        public string Secgfirstname
        {
            get { return secgfirstname; }
            set { secgfirstname = value; }
        }

        private string secglastname;

        public string Secglastname
        {
            get { return secglastname; }
            set { secglastname = value; }
        }

        private int noOfguest;

        public int NoOfguest
        {
            get { return noOfguest; }
            set { noOfguest = value; }
        }

        private string roomID;

        public string RoomID
        {
            get { return roomID; }
            set { roomID = value; }
        }

        private string roomtype;

        public string Roomtype
        {
            get { return roomtype; }
            set { roomtype = value; }
        }

        private int roomlevel;

        public int Roomlevel
        {
            get { return roomlevel; }
            set { roomlevel = value; }
        }

        private int numberofbed;

        public int Numberofbed
        {
            get { return numberofbed; }
            set { numberofbed = value; }
        }

        private string bedsize;

        public string Bedsize
        {
            get { return bedsize; }
            set { bedsize = value; }
        }

        public GuestinRoom(string checkindate,string checkoutndate,string mgtitle,string mgfirstname,string mglastname,string secgfirstname,string secglastname,int noOfguest,string roomID,string roomtype,int roomlevel,int numberofbed,string bedsize)
        {
            this.checkindate = checkindate;
            this.checkoutndate = checkoutndate;
            this.mgtitle = mgtitle;
            this.mgfirstname = mgfirstname;
            this.mglastname = mglastname;
            this.secgfirstname = secgfirstname;
            this.secglastname = secglastname;
            this.noOfguest = noOfguest;//int
            this.roomID = roomID;
            this.roomtype = roomtype;
            this.roomlevel = roomlevel;//int
            this.numberofbed = numberofbed;//int
            this.bedsize = bedsize;
        }

        public GuestinRoom()
        {

        }




    }
}