﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DRHMS
{
    public partial class WebForm6 : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection("Data Source=USER-PC\\SQLEXPRESS;Initial Catalog=DelonixRegia;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string str = "SELECT Room.RoomType, Booking.RoomNumber, Booking.CheckInDate, Guests.MGTitle, Guests.MGFirstName, Guests.MGLastName, Guests.MGPhoneNumber, Guests.NoOfGuest FROM Booking INNER JOIN Room ON Booking.RoomID = Room.RoomID INNER JOIN Guests ON Booking.MGPassportNo = Guests.MGPassportNo WHERE Booking.CheckInDate=@CheckInDate";
            SqlCommand xp = new SqlCommand(str,con );
            xp.Parameters.Add("@CheckInDate", SqlDbType.VarChar).Value = TextBox1.Text;
            con.Open();
            xp.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = xp;
            DataSet ds = new DataSet();
            da.Fill(ds, "CheckInDate");
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();

            if (TextBox1.Text == String.Empty)
            {
                Label2.Text = "Please enter Check in date";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Report centre.aspx");
        }
    }
}