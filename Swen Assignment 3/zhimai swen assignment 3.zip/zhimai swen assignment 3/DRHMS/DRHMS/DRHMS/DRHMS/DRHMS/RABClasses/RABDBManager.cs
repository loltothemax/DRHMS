﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DRHMS.RABClasses;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections;

namespace DRHMS.RABClasses
{
    public class RABDBManager
    {
        //Retrieve All Distinct Room Type 
        public static ArrayList GetAllRoomType()
        {
            ArrayList result = new ArrayList();
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT DISTINCT RoomType FROM Room";
                SqlDataReader dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    Room r = new Room();
                    r.RoomType = (string)dr["RoomType"];
                    result.Add(r);
                }
                dr.Close();
                conn.Close();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return result;
        }

        //Retrieve All Room ID By Room Type
        public static ArrayList GetAllRoomID(string roomType)
        {
            ArrayList result = new ArrayList();
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT RoomID FROM Room WHERE @RoomType = RoomType AND Occupied = 'Available'";
                comm.Parameters.AddWithValue("@RoomType", roomType);
                SqlDataReader dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    Room r = new Room();
                    r.RoomID = (string)dr["RoomID"];
                    result.Add(r);
                }
                dr.Close();
                conn.Close();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return result;
        }

        //Create Guest
        public static int InsertGuests(Guests guest)
        {
            int rowsinserted = 0;

            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "INSERT INTO Guests(MGPassportNo,MGTitle,MGFirstName,MGLastName,SecGFirstName,SecGLastName,ThiGFirstName,ThiGLastName,FouGFirstName,FouGLastName,FifGFirstName,FifGLastName,NoOfGuest,MGNationality,MGFullAddress,MGPhoneNumber,MGEmailAddress)"
                    + " VALUES (@MGPassportNo,@MGTitle,@MGFirstName,@MGLastName,@SecGFirstName,@SecGLastName,@ThiGFirstName,@ThiGLastName,@FouGFirstName,@FouGLastName,@FifGFirstName,@FifGLastName,@NoOfGuest,@MGNationality,@MGFullAddress,@MGPhoneNumber,@MGEmailAddress)";
                comm.Parameters.AddWithValue("@MGPassportNo", guest.MGPassportNo);
                comm.Parameters.AddWithValue("@MGTitle", guest.MGTitle);
                comm.Parameters.AddWithValue("@MGFirstName", guest.MGFirstName);
                comm.Parameters.AddWithValue("@MGLastName", guest.MGLastName);
                comm.Parameters.AddWithValue("@SecGFirstName", guest.SecGFirstName);
                comm.Parameters.AddWithValue("@SecGLastName", guest.SecGLastName);
                comm.Parameters.AddWithValue("@ThiGFirstName", guest.ThiGFirstName);
                comm.Parameters.AddWithValue("@ThiGLastName", guest.ThiGLastName);
                comm.Parameters.AddWithValue("@FouGFirstName", guest.FouGFirstName);
                comm.Parameters.AddWithValue("@FouGLastName", guest.FouGLastName);
                comm.Parameters.AddWithValue("@FifGFirstName", guest.FifGFirstName);
                comm.Parameters.AddWithValue("@FifGLastName", guest.FifGLastName);
                comm.Parameters.AddWithValue("@NoOfGuest", guest.NoOfGuest);
                comm.Parameters.AddWithValue("@MGNationality", guest.MGNationality);
                comm.Parameters.AddWithValue("@MGFullAddress", guest.MGFullAddress);
                comm.Parameters.AddWithValue("@MGPhoneNumber", guest.MGPhoneNumber);
                comm.Parameters.AddWithValue("@MGEmailAddress", guest.MGEmailAddress);
                rowsinserted = comm.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return rowsinserted;
        }

        //Create Invoice
        public static int InsertInvoice(InvoiceClass invoice)
        {
            int rowsinserted = 0;

            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "INSERT INTO Invoice(InvoiceID,MGPassportNo,MGTitle,MGFirstName,MGLastName,BookingID,CheckInDate,CheckOutDate,NoOfDays,RoomID,RoomRates,ConsumedItemsCost,TotalBill,PaymentType,CreditCardNo,CardHolderName,CardExpiryDate)"
                    + " VALUES (@InvoiceID,@MGPassportNo,@MGTitle,@MGFirstName,@MGLastName,@BookingID,@CheckInDate,@CheckOutDate,@NoOfDays,@RoomID,@RoomRates,@ConsumedItemsCost,@TotalBill,@PaymentType,@CreditCardNo,@CardHolderName,@CardExpiryDate)";
                comm.Parameters.AddWithValue("@InvoiceID", invoice.InvoiceID);
                comm.Parameters.AddWithValue("@MGPassportNo", invoice.MGPassportNo);
                comm.Parameters.AddWithValue("@MGTitle", invoice.MGTitle);
                comm.Parameters.AddWithValue("@MGFirstName", invoice.MGFirstName);
                comm.Parameters.AddWithValue("@MGLastName", invoice.MGLastName);
                comm.Parameters.AddWithValue("@BookingID", invoice.BookingID);
                comm.Parameters.AddWithValue("@CheckInDate", invoice.CheckInDate);
                comm.Parameters.AddWithValue("@CheckOutDate", invoice.CheckOutDate);
                comm.Parameters.AddWithValue("@NoOfDays", invoice.NoOfDays);
                comm.Parameters.AddWithValue("@RoomID", invoice.RoomID);
                comm.Parameters.AddWithValue("@RoomRates", invoice.RoomRates);
                comm.Parameters.AddWithValue("@ConsumedItemsCost", invoice.ConsumedItemsCost);
                comm.Parameters.AddWithValue("@TotalBill", invoice.TotalBill);
                comm.Parameters.AddWithValue("@PaymentType", invoice.PaymentType);
                comm.Parameters.AddWithValue("@CreditCardNo", invoice.CreditCardNo);
                comm.Parameters.AddWithValue("@CardHolderName", invoice.CardHolderName);
                comm.Parameters.AddWithValue("@CardExpiryDate", invoice.CardExpiryDate);
                
                rowsinserted = comm.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return rowsinserted;
        }

        //Create Booking
        public static int InsertBooking(Booking booking)
        {
            int rowsinserted = 0;

            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "INSERT INTO Booking(BookingID,MGPassportNo,RoomID,StaffID,RoomType,NoOfDays,CheckInDate,CheckInTime,CheckOutDate,CheckOutTime,Remarks)"
                    + " VALUES (@BookingID,@MGPassportNo,@RoomID,@StaffID,@RoomType,@NoOfDays,@CheckInDate,@CheckInTime,@CheckOutDate,@CheckOutTime,@Remarks)";
                comm.Parameters.AddWithValue("@BookingID", booking.BookingID);
                comm.Parameters.AddWithValue("@MGPassportNo", booking.MGPassportNo);
                comm.Parameters.AddWithValue("@RoomID", booking.RoomID);
                comm.Parameters.AddWithValue("@StaffID", booking.StaffID);
                comm.Parameters.AddWithValue("@RoomType", booking.RoomType);
                comm.Parameters.AddWithValue("@NoOfDays", booking.NoOfDays);
                comm.Parameters.AddWithValue("@CheckInDate", booking.CheckInDate);
                comm.Parameters.AddWithValue("@CheckInTime", booking.CheckInTime);
                comm.Parameters.AddWithValue("@CheckOutDate", booking.CheckOutDate);
                comm.Parameters.AddWithValue("@CheckOutTime", booking.CheckOutTime);
                comm.Parameters.AddWithValue("@Remarks", booking.Remarks);
                rowsinserted = comm.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return rowsinserted;
        }

        //Create Payment Details
        public static int InsertPaymentDetails(PaymentDetails paymentDetails)
        {
            int rowsinserted = 0;

            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "INSERT INTO PaymentDetails(MGPassportNo,InvoiceID,PaymentType,CardHolderName,CreditCardNo,CardExpiryDate)"
                    + " VALUES (@MGPassportNo,@InvoiceID,@PaymentType,@CardHolderName,@CreditCardNo,@CardExpiryDate)";
                comm.Parameters.AddWithValue("@MGPassportNo", paymentDetails.MGPassportNo);
                comm.Parameters.AddWithValue("@InvoiceID", paymentDetails.InvoiceID);
                comm.Parameters.AddWithValue("@PaymentType", paymentDetails.PaymentType);
                comm.Parameters.AddWithValue("@CardHolderName", paymentDetails.CardHolderName);
                comm.Parameters.AddWithValue("@CreditCardNo", paymentDetails.CreditCardNo);
                comm.Parameters.AddWithValue("@CardExpiryDate", paymentDetails.CardExpiryDate);
                rowsinserted = comm.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return rowsinserted;
        }

        //Update Room By Setting Occupied To Reserved By Room ID
        public static void SetOccupiedByRoomID(string roomID)
        {
            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "UPDATE Room SET Occupied = 'Reserved' WHERE @RoomID = RoomID";
                comm.Parameters.AddWithValue("@RoomID", roomID);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Retrieve All Reservation Booking By Check-In Date 
        public static ArrayList GetBookingWhoIsReserved(string checkInDate)
        {
            ArrayList result = new ArrayList();
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT b.MGPassportNo, b.RoomID, b.RoomType, b.NoOfDays, b.CheckInDate, b.CheckOutDate FROM Guests g, Booking b, Room r WHERE g.MGPassportNo=b.MGPassportNo AND b.RoomID=r.RoomID AND b.CheckInDate = @CheckInDate AND r.Occupied = 'Reserved'";
                comm.Parameters.AddWithValue("@CheckInDate", checkInDate);
                SqlDataReader dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    Booking b = new Booking();
                    b.MGPassportNo = (string)dr["MGPassportNo"];
                    b.RoomID = (string)dr["RoomID"];
                    b.RoomType = (string)dr["RoomType"];
                    b.NoOfDays = (int)dr["NoOfDays"];
                    b.CheckInDate = (string)dr["CheckInDate"];
                    b.CheckOutDate = (string)dr["CheckOutDate"];
                    result.Add(b);
                }
                dr.Close();
                conn.Close();
            }
            catch (SqlException e)
            {
                throw e;
            }
            return result;
        }

        //Get Booking By Passport Number
        public static Booking GetBookingByPassportNo(string passportNo)
        {

            Booking gb = new Booking();
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT * FROM Booking WHERE MGPassportNo=@MGPassportNo";
                comm.Parameters.AddWithValue("@MGPassportNo", passportNo);
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.Read())
                {
                    gb.BookingID = (string)dr["BookingID"];
                    gb.MGPassportNo = (string)dr["MGPassportNo"];
                    gb.RoomID = (string)dr["RoomID"];
                    gb.StaffID = (string)dr["StaffID"];
                    gb.RoomType = (string)dr["RoomType"];
                    gb.NoOfDays = (int)dr["NoOfDays"];
                    gb.CheckInDate = (string)dr["CheckInDate"];
                    gb.CheckInTime = (string)dr["CheckInTime"];
                    gb.CheckOutDate = (string)dr["CheckOutDate"];
                    gb.CheckOutTime = (string)dr["CheckOutTime"];
                    gb.Remarks = (string)dr["Remarks"];
                }
            }
            catch (SqlException e)
            {
                throw e;
            }
            return gb;
        }

        //Get Guest By Passport Number
        public static Guests GetGuestByPassportNo(string passportNo)
        {

            Guests gg = new Guests();
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT * FROM Guests WHERE MGPassportNo=@MGPassportNo";
                comm.Parameters.AddWithValue("@MGPassportNo", passportNo);
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.Read())
                {
                    gg.MGPassportNo = (string)dr["MGPassportNo"];
                    gg.MGTitle = (string)dr["MGTitle"];
                    gg.MGFirstName = (string)dr["MGFirstName"];
                    gg.MGLastName = (string)dr["MGLastName"];
                    gg.SecGFirstName = (string)dr["SecGFirstName"];
                    gg.SecGLastName = (string)dr["SecGLastName"];
                    gg.ThiGFirstName = (string)dr["ThiGFirstName"];
                    gg.ThiGLastName= (string)dr["ThiGLastName"];
                    gg.FouGFirstName = (string)dr["FouGFirstName"];
                    gg.FouGLastName = (string)dr["FouGLastName"];
                    gg.FifGFirstName = (string)dr["FifGFirstName"];
                    gg.FifGLastName = (string)dr["FifGLastName"];
                    gg.NoOfGuest = (int)dr["NoOfGuest"];
                    gg.MGNationality = (string)dr["MGNationality"];
                    gg.MGFullAddress = (string)dr["MGFullAddress"];
                    gg.MGPhoneNumber = (string)dr["MGPhoneNumber"];
                    gg.MGEmailAddress = (string)dr["MGEmailAddress"];
                }
            }
            catch (SqlException e)
            {
                throw e;
            }
            return gg;
        }

        //Update Room By Setting Occupied To Booked By Room ID
        public static void SetBookedByRoomID(string roomID)
        {
            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "UPDATE Room SET Occupied = 'Booked' WHERE @RoomID = RoomID";
                comm.Parameters.AddWithValue("@RoomID", roomID);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Update Booking By Setting Check-In Time By Passport Number
        public static void SetCheckInTimeByPassportNo(string passportNo, string checkInTime)
        {
            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "UPDATE Booking SET CheckInTime = @CheckInTime WHERE @MGPassportNo = MGPassportNo";
                comm.Parameters.AddWithValue("@MGPassportNo", passportNo);
                comm.Parameters.AddWithValue("@CheckInTime", checkInTime);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Update Room By Setting Occupied To Available
        public static void SetAvailableByRoomID(string roomID)
        {
            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "UPDATE Room SET Occupied = 'Available' WHERE @RoomID = RoomID";
                comm.Parameters.AddWithValue("@RoomID", roomID);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Update Booking By Setting Check-Out Time By Passport Number 
        public static void SetCheckOutTimeByPassportNo(string passportNo, string checkOutTime)
        {
            SqlConnection conn = null;

            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "UPDATE Booking SET CheckOutTime = @CheckOutTime WHERE @MGPassportNo = MGPassportNo";
                comm.Parameters.AddWithValue("@MGPassportNo", passportNo);
                comm.Parameters.AddWithValue("@CheckOutTime", checkOutTime);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Get Room Rates By Room Type 
        public static double GetRatesByRoomType(string roomType)
        {
            double roomrates = 0.0;
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT RoomRates FROM Room WHERE @RoomType = RoomType";
                comm.Parameters.AddWithValue("@RoomType", roomType);
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.Read())
                {
                    roomrates = Convert.ToDouble(dr["RoomRates"]);
                }
                dr.Close();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
            return roomrates;
        }

        //Get Booking ID By Passport Number
        public static string GetBookingIDByPassportNo(string passportNo)
        {
            string BookingID = "";
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
                conn.Open();
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.CommandText = "SELECT BookingID FROM Booking WHERE @MGPassportNo = MGPassportNo";
                comm.Parameters.AddWithValue("@MGPassportNo", passportNo);
                SqlDataReader dr = comm.ExecuteReader();
                if (dr.Read())
                {
                    BookingID = (string)dr["BookingID"];
                }
                dr.Close();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
            return BookingID;
        }

    }
}