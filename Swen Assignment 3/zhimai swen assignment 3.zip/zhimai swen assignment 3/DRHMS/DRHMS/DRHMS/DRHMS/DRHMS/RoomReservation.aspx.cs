﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DRHMS
{
    public partial class RoomReservation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get Information from previous web form to show in the form
            lblCheckInDate.Text = Request.QueryString["CheckInDate"];
            lblCheckOutDate.Text = Request.QueryString["CheckOutDate"];
            lblNoOfDaysStay.Text = Request.QueryString["NoOfDays"];
            lblRoomType.Text = Request.QueryString["RoomType"];
            lblRoomID.Text = Request.QueryString["RoomID"];
            lblPassportNo.Text = Request.QueryString["MGPassportNo"];
            lblTitle.Text = Request.QueryString["MGTitle"];
            lblFirstName.Text = Request.QueryString["MGFirstName"];
            lblLastName.Text = Request.QueryString["MGLastName"];
            lblSFirstName.Text = Request.QueryString["SecGFirstName"];
            lblSLastName.Text = Request.QueryString["SecGLastName"];
            lblTFirstName.Text = Request.QueryString["ThiGFirstName"];
            lblTLastName.Text = Request.QueryString["ThiGLastName"];
            lblFoFirstName.Text = Request.QueryString["FouGFirstName"];
            lblFoLastName.Text = Request.QueryString["FouGLastName"];
            lblFiFirstName.Text = Request.QueryString["FifGFirstName"];
            lblFiLastName.Text = Request.QueryString["FifGLastName"];
            lblNoOfGuest.Text = Request.QueryString["NoOfGuest"];
            lblNationality.Text = Request.QueryString["MGNationality"];
            lblFullAddress.Text = Request.QueryString["MGFullAddress"];
            lblPhoneNumber.Text = Request.QueryString["MGPhoneNumber"];
            lblEmailAddress.Text = Request.QueryString["MGEmailAddress"];
            lblRemarks.Text = Request.QueryString["Remarks"];
            lblStaffID.Text = Request.QueryString["StaffID"];
        }

        protected void btnBackTRBF_Click(object sender, EventArgs e)
        {
            Response.Redirect("RoomBooking.aspx?");
        }
    }
}