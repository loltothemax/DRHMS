﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DRHMS.RABClasses;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DRHMS
{
    public partial class ReservationGuest_Information : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearchMG_Click(object sender, EventArgs e)
        {
            //Search and get booking by passport number 
            string passportNo = tbxSearchMG.Text;
            Booking booking = RABDBManager.GetBookingByPassportNo(passportNo);

            //search and get guest by passport number
            Guests guest = RABDBManager.GetGuestByPassportNo(passportNo);

            //show guest and booking information in form
            lblRCICID.Text = booking.CheckInDate;
            lblRCICOD.Text = booking.CheckOutDate;
            lblRCIRT.Text = booking.RoomType;
            lblRCIRI.Text = booking.RoomID;
            lblRCITitle.Text = guest.MGTitle;
            lblRCIFirstName.Text = guest.MGFirstName;
            lblRCILastName.Text = guest.MGLastName;
            lblRCINOG.Text = guest.NoOfGuest.ToString();
            lblRCINationality.Text = guest.MGNationality;
            lblRCIFullAddress.Text = guest.MGFullAddress;
            lblRCIPhoneNo.Text = guest.MGPhoneNumber;
            lblRCIEmailAddress.Text = guest.MGEmailAddress;
        }

        protected void btnRCompleteCI_Click(object sender, EventArgs e)
        {
            string ps = tbxSearchMG.Text;
            string roomID = lblRCIRI.Text;

            //create check-in time using DateTime.Now function
            string checkInTime = DateTime.Now.ToString("HH:mm:ss");

            //set occupied to booked 
            RABDBManager.SetBookedByRoomID(roomID);

            //set check-in time by passport number
            RABDBManager.SetCheckInTimeByPassportNo(ps, checkInTime);

            Response.Redirect("RoomBooking.aspx?");
        }

        protected void btnRGIBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("Check-In.aspx?");
        }
    }
}