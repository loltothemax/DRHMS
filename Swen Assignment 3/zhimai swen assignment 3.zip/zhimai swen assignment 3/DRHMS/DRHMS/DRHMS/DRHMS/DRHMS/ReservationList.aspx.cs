﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DRHMS.RABClasses;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DRHMS
{
    public partial class ReservationList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnRetrieve_Click(object sender, EventArgs e)
        {
            //Retrieve all reservation booking by check-in date 
            string checkInDate = tbxCheckInDate.Text;
            ArrayList book = new ArrayList();
            book = RABDBManager.GetBookingWhoIsReserved(checkInDate);

            foreach(Booking bk in book.ToArray())
            {
                Booking z = new Booking();
                z.MGPassportNo = bk.MGPassportNo;
                z.RoomID = bk.RoomID;
                z.RoomType = bk.RoomType;
                z.NoOfDays = bk.NoOfDays;
                z.CheckInDate = bk.CheckInDate;
                z.CheckOutDate = bk.CheckOutDate;
            }

            //show reservation bookings on gridview
            GridViewReservationList.DataSource = book;
            GridViewReservationList.DataBind();
        }

        protected void btnRLBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("RoomBooking.aspx?");
        }

        protected void GridViewReservationList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
          
        }
    }
}