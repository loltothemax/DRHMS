﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DRHMS.RABClasses;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DRHMS
{
    public partial class GuestInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //Populate Distinct Room Type DropDownList 
                ArrayList Room = new ArrayList();
                Room = RABDBManager.GetAllRoomType();
                foreach(Room room in Room.ToArray())
                {
                    Room r = new Room();
                    r.RoomID = room.RoomID;
                    r.RoomType = room.RoomType;
                    r.RoomLevel = room.RoomLevel;
                    r.NumberOfBed = room.NumberOfBed;
                    r.BedSize = room.BedSize;
                    r.RoomRates = room.RoomRates;
                    r.NoCanDrinks = room.NoCanDrinks;
                    r.NoPotatoesChip = room.NoPotatoesChip;
                    r.Occupied = room.Occupied;
                }
                ddlRRGIRoomType.DataSource = Room;
                ddlRRGIRoomType.DataValueField = "RoomType";
                ddlRRGIRoomType.DataTextField = "RoomType";
                ddlRRGIRoomType.DataBind();
            }
            
        }

        protected void ddlRRGIRoomType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Populate Room ID DropDownList by room type selected
            string roomType = ddlRRGIRoomType.Text;
            ArrayList roomid = new ArrayList();
            roomid = RABDBManager.GetAllRoomID(roomType);

            foreach (Room r in roomid.ToArray())
            {
                Room a = new Room();
                a.RoomID = r.RoomID;
                a.RoomType = r.RoomType;
                a.RoomLevel = r.RoomLevel;
                a.NumberOfBed = r.NumberOfBed;
                a.BedSize = r.BedSize;
                a.RoomRates = r.RoomRates;
                a.NoCanDrinks = r.NoCanDrinks;
                a.NoPotatoesChip = r.NoPotatoesChip;
                a.Occupied = r.Occupied;
            }
            ddlRRGIRoomID.DataSource = roomid;
            ddlRRGIRoomID.DataValueField = "RoomID";
            ddlRRGIRoomID.DataTextField = "RoomID";
            ddlRRGIRoomID.DataBind();
        }

        protected void btnGISubmit_Click(object sender, EventArgs e)
        {
            //Enter Room Reservation Details and Guest Information for room reservation
            string checkInDate = ddlDate.SelectedValue + "/" + ddlMonth.SelectedValue + "/" + ddlYear.SelectedValue;
            string checkOutDate = ddlCoDate.SelectedValue + "/" + ddlCoMonth.SelectedValue + "/" + ddlCoYear.SelectedValue;
            int noOfDaysStay = Convert.ToInt32(ddlDays.SelectedValue);
            string roomType = ddlRRGIRoomType.SelectedValue;
            string roomID = ddlRRGIRoomID.SelectedValue;
            string mgPassportNo = tbxMGPassportNo.Text;
            string mgTitle = ddlMGTitle.SelectedValue;
            string mgFirstName = tbxMGFirstName.Text;
            string mgLastName = tbxMGLastName.Text;
            string sgFirstName = tbx2GFirstName.Text;
            string sgLastName = tbx2GLastName.Text;
            string tgFirstName = tbx3GFirstName.Text;
            string tgLastName = tbx3GLastName.Text;
            string fourgFirstName = tbx4GFirstName.Text;
            string fourgLastName = tbx4GLastName.Text;
            string fivegFirstName = tbx5GFirstName.Text;
            string fivegLastName = tbx5GLastName.Text;
            int noOfGuests = Convert.ToInt32(ddlNoOfGuest.SelectedValue);
            string mgNationality = tbxMGNationality.Text;
            string mgFullAddress = tbxMGFullAddress.Text;
            string mgPhoneNumber = tbxMGPhoneNo.Text;
            string mgEmailAddress = tbxMGEmailAddress.Text;
            string remarks = tbxRemarks.Text;
            string serveByStaff = tbxServeStaffID.Text;

            //put information to querystring for sending information to the next web form
            string querystring = "MGPassportNo=" + mgPassportNo;
            querystring += "&" + "MGTitle=" + mgTitle;
            querystring += "&" + "MGFirstName=" + mgFirstName;
            querystring += "&" + "MGLastName=" + mgLastName;
            querystring += "&" + "SecGFirstName=" + sgFirstName;
            querystring += "&" + "SecGLastName=" + sgLastName;
            querystring += "&" + "ThiGFirstName=" + tgFirstName;
            querystring += "&" + "ThiGLastName=" + tgLastName;
            querystring += "&" + "FouGFirstName=" + fourgFirstName;
            querystring += "&" + "FouGLastName=" + fourgLastName;
            querystring += "&" + "FifGFirstName=" + fivegFirstName;
            querystring += "&" + "FifGLastName=" + fivegLastName;
            querystring += "&" + "NoOfGuest=" + noOfGuests;
            querystring += "&" + "MGNationality=" + mgNationality;
            querystring += "&" + "MGFullAddress=" + mgFullAddress;
            querystring += "&" + "MGPhoneNumber=" + mgPhoneNumber;
            querystring += "&" + "MGEmailAddress=" + mgEmailAddress;
            querystring += "&" + "CheckInDate=" + checkInDate;
            querystring += "&" + "CheckOutDate=" + checkOutDate;
            querystring += "&" + "NoOfDays=" + noOfDaysStay;
            querystring += "&" + "RoomType=" + roomType;
            querystring += "&" + "RoomID=" + roomID;
            querystring += "&" + "Remarks=" + remarks;
            querystring += "&" + "StaffID=" + serveByStaff;

            //Create booking ID using DateTime.Now Function
            string bookingID = "bk" + DateTime.Now.ToString("dd-MM-yyyy-HHmmss");
            
            //Set Check-In Time and Check-Out Time to null
            string checkInTime = "";
            string checkOutTime = "";

            //Insert Guest Information To Datebase Guest Table
            Guests G = new Guests(tbxMGPassportNo.Text, ddlMGTitle.SelectedValue, tbxMGFirstName.Text, tbxMGLastName.Text, tbx2GFirstName.Text, tbx2GLastName.Text, tbx3GFirstName.Text, tbx3GLastName.Text, tbx4GFirstName.Text, tbx4GLastName.Text, tbx5GFirstName.Text, tbx5GLastName.Text, Convert.ToInt32(ddlNoOfGuest.SelectedValue), tbxMGNationality.Text, tbxMGFullAddress.Text, tbxMGPhoneNo.Text, tbxMGEmailAddress.Text);
            RABDBManager.InsertGuests(G);

            //Insert Room Reservation Details to Database Booking Table
            Booking B = new Booking(bookingID, tbxMGPassportNo.Text, ddlRRGIRoomID.SelectedValue, tbxServeStaffID.Text, ddlRRGIRoomType.SelectedValue, Convert.ToInt32(ddlDays.SelectedValue), checkInDate, checkInTime, checkOutDate, checkOutTime, tbxRemarks.Text);
            RABDBManager.InsertBooking(B);

            //Set Reserved for Occupied column in Room Table to show the room is reserved
            RABDBManager.SetOccupiedByRoomID(roomID);

            //transfer information using querystring to next web form
            Server.Transfer("RoomReservation.aspx?" + querystring);
        }

        protected void btnGIBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("RoomBooking.aspx?");
        } 
    }
}