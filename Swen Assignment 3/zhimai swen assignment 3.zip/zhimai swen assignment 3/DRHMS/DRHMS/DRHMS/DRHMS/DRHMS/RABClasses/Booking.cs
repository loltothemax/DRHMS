﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS.RABClasses
{
    public class Booking
    {
        //Attributes
        private string bookingID; //booking ID
        private string mgPassportNo; //main guest passport number
        private string roomID; // room ID
        private string staffID; //staff ID
        private string roomType; //room type
        private int noOfDays; // number of days
        private string checkInDate; //check-in date
        private string checkInTime; //check-in time
        private string checkOutDate; //check-out date
        private string checkOutTime; //check-out time
        private string remarks; //remarks

        //Constructor
        public Booking(string bookingID, string mgPassportNo, string roomID, string staffID, string roomType, int noOfDays, string checkInDate, string checkInTime, string checkOutDate, string checkOutTime, string remarks)
        {
            this.bookingID = bookingID;
            this.mgPassportNo = mgPassportNo;
            this.roomID = roomID;
            this.staffID = staffID;
            this.roomType = roomType;
            this.noOfDays = noOfDays;
            this.checkInDate = checkInDate;
            this.checkInTime = checkInTime;
            this.checkOutDate = checkOutDate;
            this.checkOutTime = checkOutTime;
            this.remarks = remarks;
        }

        //Empty Constructor
        public Booking()
        {

        }

        //Get and Set methods 
        public string BookingID
        {
            get { return bookingID; }
            set { bookingID = value; }
        }

        //Get and Set methods 
        public string MGPassportNo
        {
            get { return mgPassportNo; }
            set { mgPassportNo = value; }
        }

        //Get and Set methods 
        public string RoomID
        {
            get { return roomID; }
            set { roomID = value; }
        }

        //Get and Set methods 
        public string StaffID
        {
            get { return staffID; }
            set { staffID = value; }
        }

        //Get and Set methods 
        public string RoomType
        {
            get { return roomType; }
            set { roomType = value; }
        }

        //Get and Set methods 
        public int NoOfDays
        {
            get { return noOfDays; }
            set { noOfDays = value; }
        }

        //Get and Set methods 
        public string CheckInDate
        {
            get { return checkInDate; }
            set { checkInDate = value; }
        }

        //Get and Set methods 
        public string CheckOutDate
        {
            get { return checkOutDate; }
            set { checkOutDate = value; }
        }

        //Get and Set methods 
        public string CheckInTime
        {
            get { return checkInTime; }
            set { checkInTime = value; }
        }

        //Get and Set methods 
        public string CheckOutTime
        {
            get { return checkOutTime; }
            set { checkOutTime = value; }
        }

        //Get and Set methods 
        public string Remarks
        {
            get { return remarks; }
            set { remarks = value; }
        }
    }
}