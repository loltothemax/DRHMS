﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DRHMS
{
    public partial class Walk_In : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //retrieve information from previous web form to show in the form
            lblWICheckInDate.Text = Request.QueryString["CheckInDate"];
            lblWICheckOutDate.Text = Request.QueryString["CheckOutDate"];
            lblWINoOfDaysStay.Text = Request.QueryString["NoOfDays"];
            lblWIRoomType.Text = Request.QueryString["RoomType"];
            lblWIRoomID.Text = Request.QueryString["RoomID"];
            lblWIPassportNo.Text = Request.QueryString["MGPassportNo"];
            lblWITitle.Text = Request.QueryString["MGTitle"];
            lblWIFirstName.Text = Request.QueryString["MGFirstName"];
            lblWILastName.Text = Request.QueryString["MGLastName"];
            lblWISFirstName.Text = Request.QueryString["SecGFirstName"];
            lblWISLastName.Text = Request.QueryString["SecGLastName"];
            lblWITFirstName.Text = Request.QueryString["ThiGFirstName"];
            lblWITLastName.Text = Request.QueryString["ThiGLastName"];
            lblWIFoFirstName.Text = Request.QueryString["FouGFirstName"];
            lblWIFoLastName.Text = Request.QueryString["FouGLastName"];
            lblWIFiFirstName.Text = Request.QueryString["FifGFirstName"];
            lblWIFiLastName.Text = Request.QueryString["FifGLastName"];
            lblWINoOfGuest.Text = Request.QueryString["NoOfGuest"];
            lblWINationality.Text = Request.QueryString["MGNationality"];
            lblWIFullAddress.Text = Request.QueryString["MGFullAddress"];
            lblWIPhoneNumber.Text = Request.QueryString["MGPhoneNumber"];
            lblWIEmailAddress.Text = Request.QueryString["MGEmailAddress"];
            lblWIRemarks.Text = Request.QueryString["Remarks"];
            lblWIStaffID.Text = Request.QueryString["StaffID"];
        }

        protected void btnBTRBF_Click(object sender, EventArgs e)
        {
            Response.Redirect("RoomBooking.aspx?");
        }
    }
}