﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DRHMS.RABClasses;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DRHMS
{
    public partial class Check_Out : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearchCOMG_Click(object sender, EventArgs e)
        {
            //get booking and guest by passport number
            string passportNo = tbxCOMGSearch.Text;
            Booking booking = RABDBManager.GetBookingByPassportNo(passportNo);
            Guests guest = RABDBManager.GetGuestByPassportNo(passportNo);

            //show guest and booking information on web form
            lblCOCID.Text = booking.CheckInDate;
            lblCOCOD.Text = booking.CheckOutDate;
            lblCORT.Text = booking.RoomType;
            lblCORI.Text = booking.RoomID;
            lblCONODS.Text = booking.NoOfDays.ToString();
            lblCOTitle.Text = guest.MGTitle;
            lblCOFirstName.Text = guest.MGFirstName;
            lblCOLastName.Text = guest.MGLastName;
            lblCONOG.Text = guest.NoOfGuest.ToString();
            lblCONationality.Text = guest.MGNationality;
            lblCOFullAddress.Text = guest.MGFullAddress;
            lblCOPhoneNo.Text = guest.MGPhoneNumber;
            lblCOEmailAddress.Text = guest.MGEmailAddress;
        }

        protected void btnPTPayment_Click(object sender, EventArgs e)
        {
            string ps = tbxCOMGSearch.Text;
            string roomID = lblCORI.Text;
            string mgTitle = lblCOTitle.Text;
            string mgFirstName = lblCOFirstName.Text;
            string mgLastName = lblCOLastName.Text;
            string checkInDate = lblCOCID.Text;
            string checkOutDate = lblCOCOD.Text;
            string noOfDaysStay = lblCONODS.Text;
            string roomType = lblCORT.Text;

            //create check out time using DateTime.Now functions
            string checkOutTime = DateTime.Now.ToString("HH:mm:ss");

            //set occupied to available
            RABDBManager.SetAvailableByRoomID(roomID);

            //set check out time by passport number
            RABDBManager.SetCheckOutTimeByPassportNo(ps, checkOutTime);

            //put information to querystring to send information to next web form
            string querystring = "MGPassportNo=" + ps;
            querystring += "&" + "MGTitle=" + mgTitle;
            querystring += "&" + "MGFirstName=" + mgFirstName;
            querystring += "&" + "MGLastName=" + mgLastName;
            querystring += "&" + "CheckInDate=" + checkInDate;
            querystring += "&" + "CheckOutDate=" + checkOutDate;
            querystring += "&" + "NoOfDays=" + noOfDaysStay;
            querystring += "&" + "RoomType=" + roomType;
            querystring += "&" + "RoomID=" + roomID;

            //send information using querystring to next web form
            Server.Transfer("InvoiceStatement.aspx?" + querystring);
        }

        protected void btnCOBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("RoomBooking.aspx?");
        }

        

        
    }
}