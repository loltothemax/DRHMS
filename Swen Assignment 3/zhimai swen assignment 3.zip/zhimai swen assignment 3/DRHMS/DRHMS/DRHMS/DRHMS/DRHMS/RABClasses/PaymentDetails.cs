﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS.RABClasses
{
    public class PaymentDetails
    {
        //Attributes
        private string mgPassportNo; //main guest passport number
        private string invoiceID; // invoice ID
        private string paymentType; //payment type
        private string cardHolderName; //card holder name
        private string creditCardNo; //credit card number
        private string cardExpiryDate; //card expiry date

        //Constructor
        public PaymentDetails(string mgPassportNo, string invoiceID, string paymentType, string cardHolderName, string creditCardNo, string cardExpiryDate)
        {
            this.mgPassportNo = mgPassportNo;
            this.invoiceID = invoiceID;
            this.paymentType = paymentType;
            this.cardHolderName = cardHolderName;
            this.creditCardNo = creditCardNo;
            this.cardExpiryDate = cardExpiryDate;
        }

        //Empty Constructor
        public PaymentDetails()
        {

        }

        //Get and Set methods 
        public string MGPassportNo
        {
            get { return mgPassportNo; }
            set { mgPassportNo = value; }
        }

        //Get and Set methods 
        public string InvoiceID
        {
            get { return invoiceID; }
            set { invoiceID = value; }
        }

        //Get and Set methods 
        public string PaymentType
        {
            get { return paymentType; }
            set { paymentType = value; }
        }

        //Get and Set methods 
        public string CardHolderName
        {
            get { return cardHolderName; }
            set { cardHolderName = value; }
        }

        //Get and Set methods 
        public string CreditCardNo
        {
            get { return creditCardNo; }
            set { creditCardNo = value; }
        }

        //Get and Set methods 
        public string CardExpiryDate
        {
            get { return cardExpiryDate; }
            set { cardExpiryDate = value; }
        }
    }
}