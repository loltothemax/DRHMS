﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DRHMS.RABClasses;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DRHMS
{
    public partial class WalkInGuestInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //populate All distinct room type dropdownlist 
                ArrayList Room = new ArrayList();
                Room = RABDBManager.GetAllRoomType();
                foreach (Room room in Room.ToArray())
                {
                    Room r = new Room();
                    r.RoomID = room.RoomID;
                    r.RoomType = room.RoomType;
                    r.RoomLevel = room.RoomLevel;
                    r.NumberOfBed = room.NumberOfBed;
                    r.BedSize = room.BedSize;
                    r.RoomRates = room.RoomRates;
                    r.NoCanDrinks = room.NoCanDrinks;
                    r.NoPotatoesChip = room.NoPotatoesChip;
                    r.Occupied = room.Occupied;
                }
                ddlWIRT.DataSource = Room;
                ddlWIRT.DataValueField = "RoomType";
                ddlWIRT.DataTextField = "RoomType";
                ddlWIRT.DataBind();
            }
        }

        protected void ddlWIRT_SelectedIndexChanged(object sender, EventArgs e)
        {
            //populate room id dropdownlist by room type selected 
            string roomType = ddlWIRT.Text;
            ArrayList roomid = new ArrayList();
            roomid = RABDBManager.GetAllRoomID(roomType);

            foreach (Room r in roomid.ToArray())
            {
                Room a = new Room();
                a.RoomID = r.RoomID;
                a.RoomType = r.RoomType;
                a.RoomLevel = r.RoomLevel;
                a.NumberOfBed = r.NumberOfBed;
                a.BedSize = r.BedSize;
                a.RoomRates = r.RoomRates;
                a.NoCanDrinks = r.NoCanDrinks;
                a.NoPotatoesChip = r.NoPotatoesChip;
                a.Occupied = r.Occupied;
            }
            ddlWIRI.DataSource = roomid;
            ddlWIRI.DataValueField = "RoomID";
            ddlWIRI.DataTextField = "RoomID";
            ddlWIRI.DataBind();
        }

        protected void btnCompleteCheckIn_Click(object sender, EventArgs e)
        {
            //Enter booking and guest information to check in to the hotel room
            string checkInDate = ddlWICID.SelectedValue + "/" + ddlWICIM.SelectedValue + "/" + ddlWICIY.SelectedValue;
            string checkOutDate = ddlWICOD.SelectedValue + "/" + ddlWICOM.SelectedValue + "/" + ddlWICOY.SelectedValue;
            int noOfDaysStay = Convert.ToInt32(ddlWINODS.SelectedValue);
            string roomType = ddlWIRT.SelectedValue;
            string roomID = ddlWIRI.SelectedValue;
            string mgPassportNo = tbxWIMGPassportNo.Text;
            string mgTitle = ddlWIMCTitle.SelectedValue;
            string mgFirstName = tbxWIMGFirstName.Text;
            string mgLastName = tbxWIMGLastName.Text;
            string sgFirstName = tbxWI2GFirstName.Text;
            string sgLastName = tbxWI2GLastName.Text;
            string tgFirstName = tbxWI3GFN.Text;
            string tgLastName = tbxWI3GLastName.Text;
            string fourgFirstName = tbxWI4GFirstName.Text;
            string fourgLastName = tbxWI4GLastName.Text;
            string fivegFirstName = tbxWI5GFirstName.Text;
            string fivegLastName = tbxWI5GLastName.Text;
            int noOfGuests = Convert.ToInt32(ddlWINoOfGuest.SelectedValue);
            string mgNationality = tbxWIMGNationality.Text;
            string mgFullAddress = tbxWIMGFullAddress.Text;
            string mgPhoneNumber = tbxWIMGPhoneNo.Text;
            string mgEmailAddress = tbxWIMGEmailAdd.Text;
            string remarks = tbxWIRemarks.Text;
            string serveByStaff = tbxWIStaffID.Text;

            //put information into querystring for sending information
            string querystring = "MGPassportNo=" + mgPassportNo;
            querystring += "&" + "MGTitle=" + mgTitle;
            querystring += "&" + "MGFirstName=" + mgFirstName;
            querystring += "&" + "MGLastName=" + mgLastName;
            querystring += "&" + "SecGFirstName=" + sgFirstName;
            querystring += "&" + "SecGLastName=" + sgLastName;
            querystring += "&" + "ThiGFirstName=" + tgFirstName;
            querystring += "&" + "ThiGLastName=" + tgLastName;
            querystring += "&" + "FouGFirstName=" + fourgFirstName;
            querystring += "&" + "FouGLastName=" + fourgLastName;
            querystring += "&" + "FifGFirstName=" + fivegFirstName;
            querystring += "&" + "FifGLastName=" + fivegLastName;
            querystring += "&" + "NoOfGuest=" + noOfGuests;
            querystring += "&" + "MGNationality=" + mgNationality;
            querystring += "&" + "MGFullAddress=" + mgFullAddress;
            querystring += "&" + "MGPhoneNumber=" + mgPhoneNumber;
            querystring += "&" + "MGEmailAddress=" + mgEmailAddress;
            querystring += "&" + "CheckInDate=" + checkInDate;
            querystring += "&" + "CheckOutDate=" + checkOutDate;
            querystring += "&" + "NoOfDays=" + noOfDaysStay;
            querystring += "&" + "RoomType=" + roomType;
            querystring += "&" + "RoomID=" + roomID;
            querystring += "&" + "Remarks=" + remarks;
            querystring += "&" + "StaffID=" + serveByStaff;

            //create booking ID using DateTime.Now functions
            string bookingID = "bk" + DateTime.Now.ToString("dd-MM-yyyy-HHmmss");

            //create check-in time using DateTime.Now functions
            string checkInTime = DateTime.Now.ToString("HH:mm:ss");
            querystring += "&" + "CheckInTime" + checkInTime;
            
            //set check-out time as null 
            string checkOutTime = "";

            //insert guest information to database guest table
            Guests G = new Guests(tbxWIMGPassportNo.Text, ddlWIMCTitle.SelectedValue, tbxWIMGFirstName.Text, tbxWIMGLastName.Text, tbxWI2GFirstName.Text, tbxWI2GLastName.Text, tbxWI3GFN.Text, tbxWI3GLastName.Text, tbxWI4GFirstName.Text, tbxWI4GLastName.Text, tbxWI5GFirstName.Text, tbxWI5GLastName.Text, Convert.ToInt32(ddlWINoOfGuest.SelectedValue), tbxWIMGNationality.Text, tbxWIMGFullAddress.Text, tbxWIMGPhoneNo.Text, tbxWIMGEmailAdd.Text);
            RABDBManager.InsertGuests(G);

            //insert booking information to database booking table
            Booking B = new Booking(bookingID, tbxWIMGPassportNo.Text, ddlWIRI.SelectedValue, tbxWIStaffID.Text, ddlWIRT.SelectedValue, Convert.ToInt32(ddlWINODS.SelectedValue), checkInDate, checkInTime, checkOutDate, checkOutTime, tbxWIRemarks.Text);
            RABDBManager.InsertBooking(B);

            //set Occupied to booked
            RABDBManager.SetBookedByRoomID(roomID);

            //send information to the next web form using querystring
            Server.Transfer("Walk-In.aspx?" + querystring);
        }

        protected void btnWIGIBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("Check-In.aspx?");
        }

        
    }
}