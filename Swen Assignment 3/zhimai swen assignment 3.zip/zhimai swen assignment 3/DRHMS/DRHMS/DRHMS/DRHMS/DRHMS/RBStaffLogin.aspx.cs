﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DRHMS.RABClasses;

namespace DRHMS
{
    public partial class RBStaffLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Verify Staff ID To Password inserted To Login
        protected void btnRBLogin_Click(object sender, EventArgs e)
        {
            string staff_ID = tbxRBStaffID.Text;
            string staff_Password = tbxRBPassword.Text;

            if (Staff.Login(staff_ID, staff_Password) == true)
            {
                Response.Redirect("RoomBooking.aspx?");
            }
            else
            {
                lblStatus.Text = "Login Unsuccessfully";
            }
        }
    }
}