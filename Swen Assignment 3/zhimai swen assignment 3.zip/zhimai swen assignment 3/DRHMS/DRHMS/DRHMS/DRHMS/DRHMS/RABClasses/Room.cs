﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS.RABClasses
{
    public class Room
    {
        //Attributes
        private string roomID; // room ID
        private string roomType; //room type
        private int roomLevel; // room level
        private int numberOfBed; // number of bed
        private string bedSize; //bed size
        private double roomRates; //room rates
        private int noCanDrinks; //number of can drinks
        private int noPotatoesChip; //number of potatoes chip
        private string occupied; //room occupancy

        //Constructor
        public Room(string roomID, string roomType, int roomLevel, int numberOfBed, string bedSize, double roomRates, int noCanDrinks, int noPotatoesChip, string occupied)
        {
            this.roomID = roomID;
            this.roomType = roomType;
            this.roomLevel = roomLevel;
            this.numberOfBed = numberOfBed;
            this.bedSize = bedSize;
            this.roomRates = roomRates;
            this.noCanDrinks = noCanDrinks;
            this.noPotatoesChip = noPotatoesChip;
            this.occupied = occupied;
        }

        //Empty Constructor
        public Room()
        {

        }

        //Get and Set methods 
        public string RoomID
        {
            get { return roomID; }
            set { roomID = value; }
        }

        //Get and Set methods 
        public string RoomType
        {
            get { return roomType; }
            set { roomType = value; }
        }

        //Get and Set methods 
        public int RoomLevel
        {
            get { return roomLevel; }
            set { roomLevel = value; }
        }

        //Get and Set methods 
        public int NumberOfBed
        {
            get { return numberOfBed; }
            set { numberOfBed = value; }
        }

        //Get and Set methods 
        public string BedSize
        {
            get { return bedSize; }
            set { bedSize = value; }
        }

        //Get and Set methods 
        public double RoomRates
        {
            get { return roomRates; }
            set { roomRates = value; }
        }

        //Get and Set methods 
        public int NoCanDrinks
        {
            get { return noCanDrinks; }
            set { noCanDrinks = value; }
        }

        //Get and Set methods 
        public int NoPotatoesChip
        {
            get { return noPotatoesChip; }
            set { noPotatoesChip = value; }
        }

        //Get and Set methods 
        public string Occupied
        {
            get { return occupied; }
            set { occupied = value; }
        }
    }
}