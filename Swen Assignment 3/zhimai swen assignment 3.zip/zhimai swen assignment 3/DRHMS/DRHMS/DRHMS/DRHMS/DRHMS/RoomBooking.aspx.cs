﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DRHMS
{
    public partial class RoomBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRoomReservation_Click(object sender, EventArgs e)
        {
            Response.Redirect("GuestInformation.aspx?");
        }

        protected void btnReservationList_Click(object sender, EventArgs e)
        {
            Response.Redirect("ReservationList.aspx?");
        }

        protected void btnCheckIn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Check-In.aspx?");
        }

        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Check-Out.aspx?");
        }
    }
}