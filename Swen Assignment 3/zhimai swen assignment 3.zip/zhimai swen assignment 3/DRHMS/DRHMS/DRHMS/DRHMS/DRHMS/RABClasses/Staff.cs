﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS.RABClasses
{
    public class Staff
    {
        //Attributes
        private string staffID; //staff id
        private string staffFirstName; //staff first name
        private string staffLastName; //staff last name
        private string password; // staff password
        private string jobTitle; //job title
        private string title; // staff title
        private string nationality; //staff nationality
        private string fullAddress; //staff full address
        private string phoneNumber; //staff phone number
        private string emailAddress; //staff email address
        private string department; // staff department
        private string dateJoined; //date joined
        private string bankAccountNo; // staff bank account number
        private string dob; //staff date of birth

        //Constructor
        public Staff(string staffID, string staffFirstName, string staffLastName, string password, string jobTitle, string title, string nationality, string fullAddress, string phoneNumber, string emailAddress, string department, string dateJoined, string bankAccountNo, string dob)
        {
            this.staffID = staffID;
            this.staffFirstName = staffFirstName;
            this.staffLastName = staffLastName;
            this.password = password;
            this.jobTitle = jobTitle;
            this.title= title;
            this.nationality = nationality;
            this.fullAddress = fullAddress;
            this.phoneNumber = phoneNumber;
            this.emailAddress = emailAddress;
            this.department = department;
            this.dateJoined = dateJoined;
            this.bankAccountNo = bankAccountNo;
            this.dob = dob;
        }

        //Empty Constructor
        public Staff()
        {

        }

        //Get and Set methods 
        public string StaffID
        {
            get { return staffID; }
            set { staffID = value; }
        }


        //Get and Set methods 
        public string StaffFirstName
        {
            get { return staffFirstName; }
            set { staffFirstName = value; }
        }

        //Get and Set methods 
        public string StaffLastName
        {
            get { return staffLastName; }
            set { staffLastName = value; }
        }

        //Get and Set methods 
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        //Get and Set methods 
        public string JobTitle
        {
            get { return jobTitle; }
            set { jobTitle = value; }
        }

        //Get and Set methods 
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        //Get and Set methods 
        public string Nationality
        {
            get { return nationality; }
            set { nationality = value; }
        }

        //Get and Set methods 
        public string FullAddress
        {
            get { return fullAddress; }
            set { fullAddress = value; }
        }

        //Get and Set methods 
        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }

        //Get and Set methods 
        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }

        //Get and Set methods 
        public string Department
        {
            get { return department; }
            set { department = value; }
        }

        //Get and Set methods 
        public string DateJoined
        {
            get { return dateJoined; }
            set { dateJoined = value; }
        }

        //Get and Set methods 
        public string BankAccountNo
        {
            get { return bankAccountNo; }
            set { bankAccountNo = value; }
        }

        //Get and Set methods 
        public string DOB
        {
            get { return dob; }
            set { dob = value; }
        }

        public static bool Login(string inputStaffID, string inputPassword)
        {
            bool success = false;
            if (inputStaffID == "RB33245" && inputPassword == "********")
            {
                success = true;
            }
            return success;
        }
    }
}