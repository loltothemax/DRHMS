﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS.RABClasses
{
    public class Guests
    {
        //Attributes
        private string mgPassportNo; //main guest passport number
        private string mgTitle; // main guest title
        private string mgFirstName; //main guest first name
        private string mgLastName; //main gust last name
        private string secgFirstName; //second guest first name
        private string secgLastName; //second guest last name
        private string thigFirstName; //third guest first name
        private string thigLastName; //third guest last name
        private string fougFirstName; //fourth guest first name
        private string fougLastName; //fourth guest last name
        private string fifgFirstName; //fifth guest first name
        private string fifgLastName; //fifth guest last name
        private int noOfGuest; //number of guest
        private string mgNationality; //main guest nationality
        private string mgFullAddress; //main guest full address
        private string mgPhoneNumber; //main guest phone number
        private string mgEmailAddress; //main guest email address

        //Constructor
        public Guests(string mgPassportNo, string mgTitle, string mgFirstName, string mgLastName, string secgFirstName, string secgLastName, string thigFirstName, string thigLastName, string fougFirstName, string fougLastName, string fifgFirstName, string fifgLastName, int noOfGuest, string mgNationality, string mgFullAddress, string mgPhoneNumber, string mgEmailAddress)
        {
            this.mgPassportNo = mgPassportNo;
            this.mgTitle = mgTitle;
            this.mgFirstName = mgFirstName;
            this.mgLastName = mgLastName;
            this.secgFirstName = secgFirstName;
            this.secgLastName = secgLastName;
            this.thigFirstName = thigFirstName;
            this.thigLastName = thigLastName;
            this.fougFirstName = fougFirstName;
            this.fougLastName = fougLastName;
            this.fifgFirstName = fifgFirstName;
            this.fifgLastName = fifgLastName;
            this.noOfGuest = noOfGuest;
            this.mgNationality = mgNationality;
            this.mgFullAddress = mgFullAddress;
            this.mgPhoneNumber = mgPhoneNumber;
            this.mgEmailAddress = mgEmailAddress;
        }

        //Empty Constructor
        public Guests()
        {

        }

        //Get and Set methods 
        public string MGPassportNo
        {
            get { return mgPassportNo; }
            set { mgPassportNo = value; }
        }

        //Get and Set methods 
        public string MGTitle
        {
            get { return mgTitle; }
            set { mgTitle = value; }
        }

        //Get and Set methods 
        public string MGFirstName
        {
            get { return mgFirstName; }
            set { mgFirstName = value; }
        }

        //Get and Set methods 
        public string MGLastName
        {
            get { return mgLastName; }
            set { mgLastName = value; }
        }

        //Get and Set methods 
        public string SecGFirstName
        {
            get { return secgFirstName; }
            set { secgFirstName = value; }
        }

        //Get and Set methods 
        public string SecGLastName
        {
            get { return secgLastName; }
            set { secgLastName = value; }
        }

        //Get and Set methods 
        public string ThiGFirstName
        {
            get { return thigFirstName; }
            set { thigFirstName = value; }
        }

        //Get and Set methods 
        public string ThiGLastName
        {
            get { return thigLastName; }
            set { thigLastName = value; }
        }

        //Get and Set methods 
        public string FouGFirstName
        {
            get { return fougFirstName; }
            set { fougFirstName = value; }
        }

        //Get and Set methods 
        public string FouGLastName
        {
            get { return fougLastName; }
            set { fougLastName = value; }
        }

        //Get and Set methods 
        public string FifGFirstName
        {
            get { return fifgFirstName; }
            set { fifgFirstName = value; }
        }

        //Get and Set methods 
        public string FifGLastName
        {
            get { return fifgLastName; }
            set { fifgLastName = value; }
        }

        //Get and Set methods 
        public int NoOfGuest
        {
            get { return noOfGuest; }
            set { noOfGuest = value; }
        }

        //Get and Set methods 
        public string MGNationality
        {
            get { return mgNationality; }
            set { mgNationality = value; }
        }

        //Get and Set methods 
        public string MGFullAddress
        {
            get { return mgFullAddress; }
            set { mgFullAddress = value; }
        }

        //Get and Set methods 
        public string MGPhoneNumber
        {
            get { return mgPhoneNumber; }
            set { mgPhoneNumber = value; }
        }

        //Get and Set methods 
        public string MGEmailAddress
        {
            get { return mgEmailAddress; }
            set { mgEmailAddress = value; }
        }
    }
}