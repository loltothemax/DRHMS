﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DRHMS.RABClasses;

namespace DRHMS
{
    public partial class Invoice : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //retrieve information from previous web form
            lblICheckInDate.Text = Request.QueryString["CheckInDate"];
            lblICheckOutDate.Text = Request.QueryString["CheckOutDate"];
            lblINoOfDaysStay.Text = Request.QueryString["NoOfDays"];
            lblIRoomID.Text = Request.QueryString["RoomID"];
            lblIPassportNo.Text = Request.QueryString["MGPassportNo"];
            lblITitle.Text = Request.QueryString["MGTitle"];
            lblIFirstName.Text = Request.QueryString["MGFirstName"];
            lblILastName.Text = Request.QueryString["MGLastName"];
            lblIRoomType.Text = Request.QueryString["RoomType"];

            //get room rates by room type
            string roomType = lblIRoomType.Text;
            double roomrates = RABDBManager.GetRatesByRoomType(roomType);
            lblIRoomRates.Text = roomrates.ToString();

            //calculate total bill
            int noOfDays = Convert.ToInt32(lblINoOfDaysStay.Text);
            double totalBill = 0.0;
            totalBill += noOfDays * roomrates;

            lblITotalBill.Text = totalBill.ToString();
        }

        protected void btnBilled_Click(object sender, EventArgs e)
        {
            string mgPassportNo = lblIPassportNo.Text;
            string mgTitle = lblITitle.Text;
            string mgFirstName = lblIFirstName.Text;
            string mgLastName = lblILastName.Text;
            string checkInDate = lblICheckInDate.Text;
            string checkOutDate = lblICheckOutDate.Text;
            string roomID = lblIRoomID.Text;
            double roomRates = Convert.ToDouble(lblIRoomRates.Text);
            //set consumed item cost to null since this information is get 
            //from housekeeping module when they check the room to see whether 
            //guest got consumed stuff we provided
            double consumedItemsCost = 0.0;
            int noOfDaysStay = Convert.ToInt32(lblINoOfDaysStay.Text);
            double totalBill = Convert.ToDouble(lblITotalBill.Text);
            string paymentType = ddlPaymentType.SelectedValue;
            string creditCardNo = tbxCreditCardNo.Text;
            string cardHolderName = tbxCHName.Text;
            string cardExpiryDate = tbxExpiryDate.Text;

            string querystring = "MGPassportNo=" + mgPassportNo;
            querystring += "&" + "MGTitle=" + mgTitle;
            querystring += "&" + "MGFirstName=" + mgFirstName;
            querystring += "&" + "MGLastName=" + mgLastName;
            querystring += "&" + "CheckInDate=" + checkInDate;
            querystring += "&" + "CheckOutDate=" + checkOutDate;
            querystring += "&" + "RoomID=" + roomID;
            querystring += "&" + "RoomRates=" + roomRates;
            querystring += "&" + "ConsumedItemsCost=" + consumedItemsCost;
            querystring += "&" + "NoOfDays=" + noOfDaysStay;
            querystring += "&" + "TotalBill=" + totalBill;
            querystring += "&" + "PaymentType=" + paymentType;
            querystring += "&" + "CreditCardNo=" + creditCardNo;
            querystring += "&" + "CardHolderName=" + cardHolderName;
            querystring += "&" + "CardExpiryDate=" + cardExpiryDate;

            //get booking ID and create invoice id using DateTime.Now function
            string bookingID = RABDBManager.GetBookingIDByPassportNo(mgPassportNo);
            string invoiceID = "inv" + DateTime.Now.ToString("dd-MM-yyyy-HHmmss");

            //insert information to database invoice table
            InvoiceClass i = new InvoiceClass(invoiceID, lblIPassportNo.Text, lblITitle.Text, lblIFirstName.Text, lblILastName.Text, bookingID, lblICheckInDate.Text, lblICheckOutDate.Text, Convert.ToInt32(lblINoOfDaysStay.Text), lblIRoomID.Text, Convert.ToDouble(lblIRoomRates.Text), consumedItemsCost, Convert.ToDouble(lblITotalBill.Text), ddlPaymentType.SelectedValue, tbxCreditCardNo.Text, tbxCHName.Text, tbxExpiryDate.Text);
            RABDBManager.InsertInvoice(i);

            //insert information to database payment detail table
            PaymentDetails p = new PaymentDetails(lblIPassportNo.Text, invoiceID, ddlPaymentType.SelectedValue, tbxCHName.Text, tbxCreditCardNo.Text, tbxExpiryDate.Text);
            RABDBManager.InsertPaymentDetails(p);
            
            Response.Redirect("RoomBooking.aspx?");
        }
    }
}