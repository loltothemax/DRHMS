﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DRHMS.RABClasses
{
    public class InvoiceClass
    {
        //Attributes
        private string invoiceID; // invoice ID
        private string mgPassportNo; //main guest passport number
        private string mgTitle; //main guest title
        private string mgFirstName; //main guest first name
        private string mgLastName;//main guest last name
        private string bookingID; //booking ID
        private string checkInDate; //check-In date
        private string checkOutDate; // check-Out Date
        private int noOfDays; // number of days
        private string roomID; //room ID
        private double roomRates; //room rates
        private double consumedItemsCost; //item consumed cost
        private double totalBill; // total bill
        private string paymentType; //payment type
        private string creditCardNo; //credit card number
        private string cardHolderName; //card holder name
        private string cardExpiryDate; //card expiry date

        //Constructor
        public InvoiceClass(string invoiceID, string mgPassportNo, string mgTitle, string mgFirstName, string mgLastName, string bookingID, string checkInDate, string checkOutDate, int noOfDays, string roomID, double roomRates, double consumedItemsCost, double totalBill, string paymentType, string creditCardNo, string cardHolderName, string cardExpiryDate)
        {
            this.invoiceID = invoiceID;
            this.mgPassportNo = mgPassportNo;
            this.mgTitle = mgTitle;
            this.mgFirstName = mgFirstName;
            this.mgLastName = mgLastName;
            this.bookingID = bookingID;
            this.checkInDate = checkInDate;
            this.checkOutDate = checkOutDate;
            this.noOfDays = noOfDays;
            this.roomID = roomID;
            this.roomRates = roomRates;
            this.consumedItemsCost = consumedItemsCost;
            this.totalBill = totalBill;
            this.paymentType = paymentType;
            this.creditCardNo = creditCardNo;
            this.cardHolderName = cardHolderName;
            this.cardExpiryDate = cardExpiryDate;
        }




        //Get and Set methods 
        public string InvoiceID
        {
            get { return invoiceID; }
            set { invoiceID = value; }
        }

        //Get and Set methods 
        public string MGPassportNo
        {
            get { return mgPassportNo; }
            set { mgPassportNo = value; }
        }

        //Get and Set methods 
        public string MGTitle
        {
            get { return mgTitle; }
            set { mgTitle = value; }
        }

        //Get and Set methods 
        public string MGFirstName
        {
            get { return mgFirstName; }
            set { mgFirstName = value; }
        }

        //Get and Set methods 
        public string MGLastName
        {
            get { return mgLastName; }
            set { mgLastName = value; }
        }

        //Get and Set methods 
        public string BookingID
        {
            get { return bookingID; }
            set { bookingID = value; }
        }

        //Get and Set methods 
        public string CheckInDate
        {
            get { return checkInDate; }
            set { checkInDate = value; }
        }

        //Get and Set methods 
        public string CheckOutDate
        {
            get { return checkOutDate; }
            set { checkOutDate = value; }
        }

        //Get and Set methods 
        public int NoOfDays
        {
            get { return noOfDays; }
            set { noOfDays = value; }
        }

        //Get and Set methods 
        public string RoomID
        {
            get { return roomID; }
            set { roomID = value; }
        }

        //Get and Set methods
        public double RoomRates
        {
            get { return roomRates; }
            set { roomRates = value; }
        }

        //Get and Set methods
        public double ConsumedItemsCost
        {
            get { return consumedItemsCost; }
            set { consumedItemsCost = value; }
        }

        //Get and Set methods
        public double TotalBill
        {
            get { return totalBill; }
            set { totalBill = value; }
        }

        //Get and Set methods
        public string PaymentType
        {
            get { return paymentType; }
            set { paymentType = value; }
        }

        //Get and Set methods
        public string CreditCardNo
        {
            get { return creditCardNo; }
            set { creditCardNo = value; }
        }

        //Get and Set methods
        public string CardHolderName
        {
            get { return cardHolderName; }
            set { cardHolderName = value; }
        }

        //Get and Set methods
        public string CardExpiryDate
        {
            get { return cardExpiryDate; }
            set { cardExpiryDate = value; }
        }
    }
}